import { CountButton } from '../count-button';

export const CartItemDetailsCountButton = CountButton;
