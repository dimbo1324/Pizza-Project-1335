export default function DashboardProducts() {
  return <div>Dashboard Products</div>;
}
